<?php

$server = "localhost";
$user = "root";
$passdb = "12110208";
$db = "cc_db";
$connect = mysqli_connect( $server, $user, $passdb, $db )or die( "Connection Error" );

?>